<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::all();
        return view('products.index',array('products'=>$products));
    }


    public function create() {
        return view('products.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'product_name' => 'required|string|max:255',
            'product_price' => 'required|numeric',
            'product_description' => 'required|string',
            'product_images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $product = new Product();
        $product->product_name = $request->product_name;
        $product->product_price = $request->product_price;
        $product->product_description = $request->product_description;

        if ($request->hasFile('product_images')) {
            $images = [];
            foreach ($request->file('product_images') as $file) {
                $imageName = time() . '_' . $file->getClientOriginalName();
                $save_path = public_path('images');
                $file_uploaded = $file->move($save_path, $imageName);
                $images[] = $imageName;
            }
            $product->product_images = json_encode($images);
        }

        $product->save();
        return response()->json($product);
    }

    public function edit($id){
        $product = Product::findOrFail($id);
        return view('products.edit',array('product'=>$product));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'product_name' => 'required|string|max:255',
            'product_price' => 'required|numeric',
            'product_description' => 'required|string',
            'product_images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $product = Product::findOrFail($id);
        $product->product_name = $request->product_name;
        $product->product_price = $request->product_price;
        $product->product_description = $request->product_description;

        if ($request->hasFile('product_images')) {
            $images = [];
            foreach ($request->file('product_images') as $file) {
                $imageName = time() . '_' . $file->getClientOriginalName();
                $file->storeAs('public/images', $imageName);
                $images[] = $imageName;
            }
            $product->product_images = json_encode($images);
        }

        $product->save();
        return response()->json($product);
    }

    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $product->delete();
        return response()->json(['message' => 'Product deleted successfully'])->header('Location', url()->previous());
    }
}
