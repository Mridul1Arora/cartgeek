<script>
    function submitMethod(event) {
        event.preventDefault();
        var formData = new FormData(document.getElementById('editProductForm'));

        $.ajax({
            url: "{{ route('products.update', $product->id) }}",
            method: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                $('#successModal').modal('show');
            },
            error: function(response) {
                alert('An error occurred. Please try again.');
            }
        });
    }
</script>